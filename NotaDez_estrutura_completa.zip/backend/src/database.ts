// src/database.ts
import mysql, { Connection } from "mysql2/promise";

export async function connectDB(): Promise<Connection> {
  try {
    const connection = await mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "",
      database: "NotaDez"
    });
    console.log("✅ Conectado ao MySQL com sucesso!");
    return connection;
  } catch (err) {
    console.error("❌ Erro ao conectar no MySQL:", err);
    throw err;
  }
}
