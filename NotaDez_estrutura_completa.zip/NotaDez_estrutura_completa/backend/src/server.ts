// src/server.ts
import { createServer, IncomingMessage, ServerResponse } from "http";
import { connectDB } from "./database";

const server = createServer(async (req: IncomingMessage, res: ServerResponse) => {
  // 🔓 Liberação de CORS (permite que o front 8080 fale com o back 3000)
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  // O navegador envia uma requisição OPTIONS antes do POST
  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  // ✅ Rota de cadastro de docente
  if (req.method === "POST" && req.url === "/api/cadastrar-docente") {
    let body = "";

    req.on("data", (chunk: Buffer) => {
      body += chunk.toString();
    });

    req.on("end", async () => {
      try {
        const { nome, email, telefone, senha } = JSON.parse(body);
        const conn = await connectDB();

        await conn.execute(
          "INSERT INTO DOCENTE (nome, email, telefone, senha) VALUES (?, ?, ?, ?)",
          [nome, email, telefone, senha]
        );

        await conn.end();

        res.writeHead(200, { "Content-Type": "text/plain" });
        res.end("Cadastro realizado com sucesso!");
      } catch (err) {
        console.error("Erro ao cadastrar docente:", err);
        res.writeHead(500, { "Content-Type": "text/plain" });
        res.end("Erro ao cadastrar docente.");
      }
    });
  } else {
    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("Rota não encontrada.");
  }
});

server.listen(3000, () => {
  console.log("🚀 Servidor rodando em http://localhost:3000");
});
