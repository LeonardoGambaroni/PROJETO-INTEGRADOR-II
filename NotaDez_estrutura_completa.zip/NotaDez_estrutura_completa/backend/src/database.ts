// src/database.ts
// Módulo de conexão com o MySQL (login real do ambiente de trabalho do aluno)

import mysql, { Connection } from "mysql2/promise";

/**
 * Cria uma conexão assíncrona com o banco de dados MySQL
 * usando as credenciais fornecidas pelo ambiente acadêmico.
 */
export async function connectDB(): Promise<Connection> {
  try {
    const connection = await mysql.createConnection({
      host: "BD-ACD",              // Nome do host do servidor (ou IP)
      user: "BD110825138",         // Seu usuário do banco
      password: "Kyvzk7",          // Sua senha do banco
      database: "BD110825138"          // Nome do banco que você criou
    });

    console.log("✅ Conectado ao MySQL com sucesso!");
    return connection;
  } catch (err) {
    console.error("❌ Erro ao conectar no MySQL:", err);
    throw err;
  }
}
